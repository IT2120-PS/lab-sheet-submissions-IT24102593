# part 01

setwd("C:\\Users\\IT24102593\\Desktop\\IT24102593")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

fix(Delivery_Times)

attach(Delivery_Times)

names(Delivery_Times) <- c("X1")

attach(Delivery_Times)

# part 02

hist(X1, main = "Histogram fro deliver times")

histogram <- hist(X1, main = "Histogram fro deliver times",breaks = seq(20, 70, length = 9, right = TRUE)

# part 03

# Install and load e1071 package for skewness
install.packages("e1071")
library(e1071)

# Calculate skewness
skewness(Delivery_Times$X1)

#part 04

histogram <- hist(X1, main = "Histogram fro deliver times",breaks = seq(20, 70, length = 9, right = TRUE))
                  
breaks <- round(histogram$breaks)

freq = histogram$counts

mids <- histogram$mids

classes <- c()

for (i in 1:length(breaks)-1) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

cbind(classes = classes, Frequency = freq)

lines(mids, freq)

plot(mids, freq, type = "l", main = "Frequancy polygon for deliver times",xlab = "deliver times", ylab = "Frequancy", ylim = c(0,max(freq)))


cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i] = 0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new, type = "l", main = "Cumalative Frequancy polygon for deliver times",xlab = "deliver times", ylab = "Frequancy", ylim = c(0,max(cum.freq)))                  

cbind(Upper = breaks, CumFreq = new)
